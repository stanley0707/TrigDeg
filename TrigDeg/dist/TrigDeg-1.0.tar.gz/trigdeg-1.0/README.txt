Description
===========

Package for calculating trigonometric data figures